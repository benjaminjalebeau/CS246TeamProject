package com.example.directory.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import com.example.directory.R;
import com.example.directory.classes.Directory;

public class NewProjectFormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_project_form);
    }

    public void createProject(View view) {
        Intent intent = new Intent(this, DirectoryActivity.class);
        EditText editTextSerial = (EditText) findViewById(R.id.editText_form_serial);
        EditText editTextModel = (EditText)findViewById(R.id.editText_form_model);
        CheckBox checkBoxPriority = (CheckBox) findViewById(R.id.checkBox_priority);
        Boolean priority = false;
        if (checkBoxPriority.isChecked()){
            priority = true;
        }
        String serial = editTextSerial.getText().toString();
        String model = editTextModel.getText().toString();
        Log.i("NewProjectFormActivity", serial);
        Log.i("NewProjectFormActivity", model);
        Log.i("NewProjectFormActivity", String.valueOf(priority));


        startActivity(intent);
    }
}