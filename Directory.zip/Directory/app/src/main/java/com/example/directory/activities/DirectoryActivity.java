package com.example.directory.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.directory.classes.Directory;
import com.example.directory.classes.PianoProject;
import com.example.directory.adapters.ProjectRecyclerAdapter;
import com.example.directory.R;

import java.util.ArrayList;

public class DirectoryActivity extends AppCompatActivity {



    // UI components
    private RecyclerView mRecyclerView;

    // vars
    private ArrayList<PianoProject> mProjects = new ArrayList<>();
    private ProjectRecyclerAdapter mProjectRecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directory);
        mRecyclerView = findViewById(R.id.recyclerView);
        initRecyclerView();

        Directory directory = new Directory();
        insertFakeProjects(directory);

    }

    public void createNewProject(View view) {
        Intent intent = new Intent(this, NewProjectFormActivity.class);
        startActivity(intent);
    }

    private void initRecyclerView(){
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mProjectRecyclerAdapter = new ProjectRecyclerAdapter(mProjects);
        mRecyclerView.setAdapter(mProjectRecyclerAdapter);
    }

    private void insertFakeProjects(Directory directory){
        for (int i = 0; i < 20; i++){
            String s = String.valueOf(i);
            PianoProject newProject = directory.createProject(s,s,s,false);
            mProjects.add(newProject);
        }
        mProjectRecyclerAdapter.notifyDataSetChanged();
    }


}