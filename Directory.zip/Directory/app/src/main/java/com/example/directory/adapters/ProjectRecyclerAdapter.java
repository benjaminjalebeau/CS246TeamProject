package com.example.directory.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.directory.R;
import com.example.directory.classes.PianoProject;

import java.util.ArrayList;

public class ProjectRecyclerAdapter extends RecyclerView.Adapter<ProjectRecyclerAdapter.ViewHolder>{

    private ArrayList<PianoProject> pianoProjects = new ArrayList<>();

    public ProjectRecyclerAdapter(ArrayList<PianoProject> pianoProjects) {
        this.pianoProjects = pianoProjects;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_project_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.serial.setText(pianoProjects.get(position).getSerial());

    }

    @Override
    public int getItemCount() {
        return pianoProjects.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView serial;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            serial = itemView.findViewById(R.id.serial_number);
        }
    }
}
